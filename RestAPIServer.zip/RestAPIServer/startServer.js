//npm install @babel/core @babel/register @babel/preset-env --save-dev for tom make import export work in node
// Transpile all code following this line with babel and use '@babel/preset-env' (aka ES6) preset.
require("@babel/register")({
  presets: ["@babel/preset-env"]
});
// Import the rest of our application.
module.exports = require('./server/server.js')