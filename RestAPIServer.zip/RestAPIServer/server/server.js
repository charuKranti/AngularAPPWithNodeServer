const express = require("express");
const server = express();
const bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var endPoints = require('./restAPIrouter');
const port = 4546;
var inContainer = process.env.CONTAINER
// support parsing of application/json type post data
server.use(bodyParser.json());
//support parsing of application/x-www-form-urlencoded post data
server.use(bodyParser.urlencoded({ extended: true }));
// this is for setting cookies
server.use(cookieParser());
server.use('/api', endPoints);
//The dist folder has our static resources (index.html, css, images)
 
if (!inContainer) {
    server.use(express.static(__dirname + '/dist'));
    console.log(__dirname);
}
 
// redirect all others to the index (HTML5 history)
server.all('/*', function(req, res) {
    res.sendFile(__dirname + '/dist/index.html');
});
 
// define the home page route
//server.get('/', function (req, res) {
  //res.cookie("SESSIONID", "krantikfwoewrwe_dsfsdfwe", {httpOnly:true, secure:true});
  //res.redirect("http://localhost:4200")
//});

server.listen(port,()=>console.log("Server is turned ON! "));
/*
https://cheatsheetseries.owasp.org/cheatsheets/HTML5_Security_Cheat_Sheet.html
https://github.com/AmitXShukla/Employee-Payroll-Salary-App-Angular-6-MEAN-Stack
https://github.com/AmitXShukla/GPS-Mobile-Tracking-App/tree/master/server
http://localhost:4546/api/
Status Codes
200: The HTTP 200 OK success status response code indicates that the request has succeeded.
201: 201 Created. The request has been fulfilled and has resulted in one or more new resources being created.
303: The HTTP response status code 303 See Other is a way to redirect web applications to a new URI, particularly after a 
     HTTP POST has been performed
401 : The 401 (Unauthorized) status code indicates that the request has not been applied because it lacks valid
      authentication credentials for the target resource.
403: The 403 Forbidden error is an HTTP status code that means that accessing the page or resource you were trying to reach        is absolutely forbidden for some reason.
404: page not found.
500: The 500 status code, or Internal Server Error, means that server cannot process the request for an unknown reason.


*/