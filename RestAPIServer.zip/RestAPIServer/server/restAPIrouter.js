const express = require('express');
const router = express.Router();
var jwt = require('jsonwebtoken');
 
import {getTotalEmp, customers, addNewItem, userDetails} from './staticDB';
var customerData = customers();
var employees = getTotalEmp();

 /*this is for adding new record in records*/
function addItem(){
    return customerData.unshift(addNewItem());
}
 /*this is for clearing expire time when user inactivity*/
const clearRecordLockSession = () => {
    customerData=customerData.filter((item)=>{
      if(item['expires']){
         if((new Date() > new Date(item['expires']))){
           item.isAvailable=true;
           delete item['expires'];
           delete item['userId'];
         }
      }
      return item
    });
};
/*this is for checking user has valid credentials or not*/
const findUser = (userId) => {
    if(!userId) return {};
    return (employees.find((item)=> item.userId == userId)) ? ( employees.find((item)=> item.userId == userId) ) : {}
}
/*this is for verifying token is valid or not*/
function verifyToken(req,res,next) {
  /*get auth header value*/
  var token;
  if('authorization' in req.headers){
    token = req.headers['authorization'].split(' ')[1]
  }
  if(!token)
    return res.status(401).send({message:"No token provided"})
    //res.sendStatus(403);
  else{
     req.token = token;
     next();
  }
}

Date.prototype.addMinutes = function(minutes) {
    this.setMinutes(this.getMinutes() + minutes);
    return this;
};

/* this is for only to pull specific key and values*/
Array.prototype.pullData = function(...params) {
  return this.map((item)=>{
     return params.reduce((obj,key)=>{
         obj[key] = item[key];
       return obj;
     },{})
  });
};

router.use(function(req, res, next) {
    // For cors or cross orgin fix.
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    next()
});
 

// Reject page route when there is none route mention
router.get('/', function (req, res) {
    res.send("Access forbidden")
});

/*this is for user login */
router.post('/login', (req, res) => {
    // user small data
    if(Object.keys(findUser(req.body.username)).length){
        let user = findUser(req.body.username);
        jwt.sign({user:user}, 'secretkey',{expiresIn:120}, (err, token) => {
             res.json({token});
        });
    }else{
        // else return 400 bad request
        res.status(400).json({ error: { message: 'Username or password is incorrect' } });
    }
    
});

/*this is for user logout*/
router.post('/logout', (req, res) => {
    res.json({message:"Successful"});
});
 
/*list of all records sending to client Note: verifyToken is for restricting API based on token  */
router.get('/userslist', verifyToken, function (req, res) {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            // return 401 not authorised if token is null or invalid
            res.status(401).json({ error: { message: 'Unauthorised' }});
        } else{
            clearRecordLockSession();
            res.status(200).json(customerData.pullData("jurneyNumber", "depdate", "ipata", "read", "status", "calledCustmer", "modified", "modifiedBy", "origin", "destination", "workdoc", "isAvailable"));
        }
    });
});
 
/*refreshed data*/
router.get('/userlist/updated', verifyToken, function (req, res) {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            // return 401 not authorised if token is null or invalid
            res.status(401).json({ error: { message: 'Unauthorised' }});
        } else{
            if(randomPick(read)){addItem();}
            clearRecordLockSession();
            res.status(200).json(customerData);
        }
    });
});
 
 
/*update session timeout for viewing record*/
router.post('/user/extend/sessiontime/:id', (request, response) => {
    if(!request.params.id){
        return response.status(400).send({message:"failure"});
    }
    let record=customerData.find((item)=>{return item.jurneyNumber==request.params.id});
    if(!record) return response.status(201).send({message:"Please provide Id"});
    if(!record.isAvailable){
       var expireTime = new Date();
       expireTime.addMinutes(2);
       customerData=customerData.filter((item)=>{
         if(item.jurneyNumber==request.params.id){
           item['expires']=expireTime;
         }
         return item
       });
       return response.status(200).send({message:"session timeupdated"});
    }
    return response.status(201).send({message:"Available"});
});
 
 /*this is for sending jurney details to client based on record id*/
router.post('/user/jurneydetails/:id', verifyToken, function (req, res) {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if(err){
            // return 401 not authorised if token is null or invalid
            res.status(401).json({ error: { message: 'Unauthorised' }});
        } else{
            if(!req.params.id){
                return res.status(400).send({message:"Please provide record id"});
            }
            let record=customerData.find((item)=>{return item.jurneyNumber==req.params.id});
            if(!record) return res.status(201).send({message:"No record found"});
            if(!record.isAvailable && !record['userId'] === authData.user.userId ){
               return res.status(201).send({message:"Record is beeing use"});
            }
            var expireTime = new Date();
            expireTime.addMinutes(2);
            customerData=customerData.filter((item)=>{
              if(item.jurneyNumber==req.params.id){
                item.isAvailable=false;
                 item['expires']=expireTime;
                 item['userId']=authData.user.userId;
              }
              return item
            });
            return res.status(200).send(userDetails());
        }
    });
    
        
});
 
module.exports = router