import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-records-list',
  templateUrl: './records-list.component.html',
  styleUrls: ['./records-list.component.css']
})
export class RecordsListComponent implements OnInit {
    results:any=[];
    constructor(private authService: AuthService, private router:Router) {
        this.authService.getPayloadData().subscribe((res)=>{
            console.log("Users: ",res);
            this.results=res;
        });
    }

    ngOnInit() {
       
    }
    
    gotoDetailsPage(item): void {
        if(item.isAvailable){
            this.router.navigate([`/details/${item.jurneyNumber}`]);
        }
    }

}
