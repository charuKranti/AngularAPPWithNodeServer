import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isShow:boolean=false;
  constructor(private authService: AuthService) { }

  ngOnInit() {
  }
  
  toggleDropdown(){
    this.isShow = !this.isShow;
    console.log(this.isShow)
  }
  logout(){
    this.authService.redirectToLogin();
  }
}
