import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  isLoggedIn:boolean = false;

  constructor(private router: Router, private http: HttpClient) { }

  login(model:any) {
    model['username'] = +model['username'];
    return this.http.post<any>('http://localhost:4546/api/login/',model);
  }

  logout() {
    sessionStorage.clear();
  }
  
  setToken(token){
    sessionStorage.setItem("token",token['token']);
  };
  
  getToken(){
    return sessionStorage.getItem("token") ? sessionStorage.getItem("token") : null;
  };
  
  redirectToLogin(){
    this.logout();
    this.router.navigate(['/login']);
  }
  
  
  // onload all users data get method
  getPayloadData(): Observable<any>{
    return this.http.get<any>('http://localhost:4546/api/userslist');
  }
  
  // dummy Refresh data API
  refreshPayloadData(id,data): Observable<any>{
    return this.http.get<any>('http://localhost:4546/api/userlist/updated');
  }
  
  // this for details page to pull data when no one is active on this record and provide ex: jurneyNumber=75425
  getUserDetails(id): Observable<any>{
    return this.http.post<any>('http://localhost:4546/api/user/jurneydetails/'+id,{});
  }
  // update user session time with setinterval and provide ex: jurneyNumber=75425
  updateSessionTime(id): Observable<any>{
    return this.http.post<any>('http://localhost:4546/api/user/extend/sessiontime/'+id,{});
  }
}
